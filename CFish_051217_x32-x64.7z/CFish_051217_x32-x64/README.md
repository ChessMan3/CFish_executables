# Cfish
C port of Stockfish

* Chess960 support probably is missing a few lines.
* Skill level support has been commented out.
* Not fully tested on Windows.
